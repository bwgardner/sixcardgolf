# Game State for Six Card Golf

from dataclasses import dataclass
from typing import Optional

from classes import Card, Pile, Deck, Hand, deal
from scoring import score_hand


class GameState:
    def __init__(self, player_names: list[str]):
        self.player_names = player_names
        self.num_players = len(player_names)

        # game level tracking
        self.round_number = 0
        self.cumulative_scores = {name: 0 for name in self.player_names}
        self.last_round_scores = None             # dict[str,int] | None

        # placeholders
        self.deck = None
        self.discard = None
        self.hands = []
        self.phase = "setup"

        # start the first round immediately upon inititalization
        self.start_new_round()

    def start_new_round(self) -> None:
        self.round_number += 1
        self.last_round_scores = None # really? it's already initialized to None in __init__()
        
        # initialize round objects
        self.deck = Deck()
        self.deck.shuffle()

        self.discard = Pile()

        self.hands = [Hand(playerID=i, playerName=name, max_cards=6) for i, name in enumerate(self.player_names)]
        deal(self.deck, self.hands, cards_each=6)
        
        # phase + setup state
        self.phase = "setup"
        self.setup_player_index = 0
        self.setup_flips_done = 0
        
        # play state
        self.turn_index = 0
        self.pending_drawn_card = None  # type: Card | None
        self.pending_draw_source = None  # "deck" or "discard" or None

        # end-of-round trigger state
        self.round_ending_player_index = None     # int | None
        self.final_turns_remaining = None         # int | None

        # prepare the discard pile
        top = self.deck.draw()
        top.reveal()
        self.discard.add(top)

        
    @property
    def cycle_number(self) -> int:
        return self.turn_index // self.num_players

    @property
    def current_player_index(self) -> int:
        return self.turn_index % self.num_players

    @property
    def current_hand(self):
        return self.hands[self.current_player_index]
    
    @property
    def current_player_name(self):
        return self.current_hand.playerName

    # def auto_hand_setup(self):
    #     for hand in self.hands:
    #         hand.cards[0].reveal()
    #         hand.cards[3].reveal()

    @property
    def setup_hand(self) -> Hand:
        return self.hands[self.setup_player_index]
    
    
    def prompt(self) -> str:
        if self.phase == "setup":
            remaining = 2 - self.setup_flips_done
            return f"{self.setup_hand.playerName} (setup, {remaining} flip(s) left) > "
        elif self.phase =="play":
            if getattr(self, "pending_drawn_card", None) is None:
                return f"{self.current_player_name} (draw: deck | discard) > "
            else:
                return f"{self.current_player_name} (resolve: swap <0-5> | discard) > "
        else:    
            return "> "
        

    def interactive_hand_setup(self, raw: str) -> None:
        """
        Interactively handle setup commands. Players must choose 2 cards in their hands to reveal.
        Accepts commands like 'flip 3' or just '3' where the number is the hand position of the card to flip.
        """
        cmd = raw.lower().strip()
        if not cmd:
            return
        
        # parse the command to extract the position of the card to flip
        pos = None
        parts = cmd.split()
        if len(parts) == 2 and parts[0] in ("flip", "reveal", "show") and parts[1].isdigit():
            pos = int(parts[1])
        elif len(parts) == 1 and parts[0].isdigit():
            pos = int(parts[0])

        if pos is None:
            print("Setup: Please select a card to flip. Type flip N, where N is a digit from 0 to 5 representing the position of the card to flip. (Or just enter the digit)")
            return
        if pos not in range(6): # needs to be 0..5
            print("Setup: Not a valid card position. Please choose a number from 0 to 5.")
            return

        hand = self.setup_hand

        if pos >= len(hand.cards):
            print("You don't have that many cards. Please choose another.")
            return

        # prevent picking a card that's already flipped
        if hand.cards[pos].faceUp:
            print("That card has already been revealed. Please choose another card.")
            return
        hand.cards[pos].reveal()
        print(f"{hand.playerName} flipped {pos}: {hand.cards[pos].display()}")
        self.setup_flips_done +=1


        if self.setup_flips_done >= 2:
            # move to next player
            self.setup_flips_done = 0
            self.setup_player_index += 1

            if self.setup_player_index >= self.num_players:
                self.phase = "play"
                self.turn_index = 0
                print("Setup complete. Begin play.")
            else:
                print(f"Setup: Now {self.setup_hand.playerName} flips 2 cards.")


    def interactive_play_step(self, raw: str) -> None:
        """
        Handle play commands.

        States:
            - If there is no pending drawn card, accept 'draw deck' or 'draaw discard'
            - If a pending drawn card exists, accept 'swap N' or 'discard'
        """

        cmd = raw.lower().strip()
        if not cmd:
            return
        
        hand = self.current_hand

        # Draw a card
        if self.pending_drawn_card is None:
            if cmd in ("draw deck", "d deck", "deck", "e"):
                c = self.deck.draw()
                c.reveal()
                self.pending_drawn_card = c
                self.pending_draw_source = "deck"
                print(f"{hand.playerName} drew: {c.display()} (from deck)")
                return
            
            if cmd in ("draw discard", "d discard", "disc", "i"):
                if self.discard.count() == 0:
                    print("Discard pile is empty.")
                    return
                c = self.discard.draw()
                c.reveal()
                self.pending_drawn_card = c
                self.pending_draw_source = "discard"
                print(f"{hand.playerName} took: {c.display()} (from discard)")
                return
            
            print("Play: draw deck | draw discard")
            return
        
        # Resolve placement of drawn card (swap/discard)
        pending = self.pending_drawn_card

        if cmd in ("discard", "x", "dump"):
            pending.reveal()
            self.discard.add(pending)
            print(f"{hand.playerName} discarded: {pending.display()}")
            self._end_turn()
            return
        
        parts = cmd.lower().split()
        if len(parts) == 2 and parts[0] in ("swap", "s") and parts[1].isdigit():
            pos = int(parts[1])
            if pos not in range(6):
                print("Swap: choose a position 0-5.")
                return
            if pos >= len(hand.cards):
                print("Swap: you don't have that many cards.")
                return
            
            outgoing = hand.cards[pos]
            hand.cards[pos] = pending
            pending.reveal()

            outgoing.reveal()
            self.discard.add(outgoing)

            print(f"{hand.playerName} swapped into {pos}: {pending.display()}")
            print(f"Discarded from hand: {outgoing.display()}")

            self._end_turn()
            return
        
        print("Resolve: swap <0-5> | discard")

    def is_hand_complete(self, hand: Hand) -> bool:
        # assumes 6-card hands; safe if you ever change size
        return len(hand.cards) >= 6 and all(c.faceUp for c in hand.cards[:6])

    def reveal_all_hands(self) -> None:
        for h in self.hands:
            for c in h.cards:
                c.reveal()

    def _end_turn(self) -> None:
        self.pending_drawn_card = None
        self.pending_draw_source = None    
        just_finished = self.current_player_index  # player who just took the turn

        print(f"[DEBUG] _end_turn called. Before increment: turn_index={self.turn_index}, current_player_index={self.current_player_index}")

        if self.round_ending_player_index is None:
            if self.is_hand_complete(self.hands[just_finished]):
                self.round_ending_player_index = just_finished
                self.final_turns_remaining = self.num_players - 1
                print(f"{self.player_names[just_finished]} completed their hand. Final turns remaining: {self.final_turns_remaining}")
        else:
            if just_finished != self.round_ending_player_index:
                self.final_turns_remaining -= 1
                print(f"Final turns remaining: {self.final_turns_remaining}")

        self.turn_index += 1

        if self.round_ending_player_index is not None and self.final_turns_remaining <= 0:
            self.end_round()

    def end_round(self) -> None:
        self.reveal_all_hands()
        round_scores = {}
        for h in self.hands:
            name = h.playerName
            round_scores[name] = score_hand(h)

        for name, s in round_scores.items():
            self.cumulative_scores[name] += s

        self.last_round_scores = round_scores


        print("\n=== Round Over! Scoring: ===")
        for name, s in round_scores.items():
            print(f"{name}: {s}     (total: {self.cumulative_scores[name]})")

        self.phase = "round_over"


    def help_text(self) -> str:
        if self.phase == "setup":
            return "Setup: flip <0-5> (or just 0-5)."
        if self.phase == "play":
            if self.pending_drawn_card is None:
                return "Play: draw deck | draw discard"
            return "Resolve: swap <0-5> | discard"
        return ""