# gamerunner.py

from gamestate import GameState
    
def render(game: GameState) -> None:
    """Render current game state in terminal"""
    print("\n" + "=" * 40)
    print(f"Phase: {game.phase}")
    print(f"Deck: {game.deck.count()} cards | Discard top: {repr(game.discard.peek()) if game.discard.count() else '(empty)'}")
    print()

    print(f"[DEBUG] turn_index={game.turn_index} current_player_index={game.current_player_index} setup_player_index={game.setup_player_index}")

    # Highlight active player
    active = game.setup_player_index if game.phase == "setup" else game.current_player_index

    for i, h in enumerate(game.hands):
        header = f">> {h.playerName} <<" if i == active else h.playerName
        print(header)
        print("\n".join(h._render_grid(indexed=True)))
        print()

def dispatch(game: GameState, cmd: str) -> bool:
    """Interprets player inputs. returns True if game loop should continue, False if game over."""
    if cmd in ("q", "quit", "exit"):
        return False
    
    if cmd in ("h", "help", "?"):
        print(game.help_text())
        return True

    if game.phase == "setup":
        game.interactive_hand_setup(cmd)
        return True
    
    if game.phase == "play":
        game.interactive_play_step(cmd)
        return True

    return False # handle unknown phase => stop

def main():
    player_names = ["Alice", "Bob"]
    game = GameState(player_names)

    print("Six Card Golf (WIP)")
    print("Commands during setup: 'flip N' or just 'N' where N is the hand position of the card to be flipped (0-5).") # does this stay here?
    print("Other commands: 'help', 'quit'\n")

    while True:
        render(game)
        cmd = input(game.prompt()).lower().strip()
        if not dispatch(game, cmd):
            print("Game Over.")
            break

        if game.phase == "round_over":
            render(game)
            print("Round finished.")
            cmd = input("Play another round? (y/n)> ").strip().lower()
            if cmd.startswith("y"):
                game.start_new_round()  # later
            else:
                break
    print("Goodbye!")

    
if __name__ == "__main__":
    main()